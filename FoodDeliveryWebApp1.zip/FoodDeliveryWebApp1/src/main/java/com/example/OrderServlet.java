package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/order")
public class OrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Logic to handle order submission
    	String itemName = request.getParameter("itemName");
    	String itemPriceStr = request.getParameter("itemPrice");

    	if (itemName != null && itemPriceStr != null && !itemPriceStr.isEmpty()) {
    	    double itemPrice = Double.parseDouble(itemPriceStr);

    	    Order order = (Order) request.getSession().getAttribute("order");
    	    if (order == null) {
    	        order = new Order();
    	        request.getSession().setAttribute("order", order);
    	    }

    	    FoodItem selectedItem = new FoodItem(itemName, itemPrice);
    	    order.addItem(selectedItem);

    	    response.sendRedirect("order.jsp");
    	} else {
    	    // Handle the case where parameters are missing or empty
    	    // For example, you could redirect the user to an error page
    	    response.sendRedirect("error.jsp");
    	}
    }
}
